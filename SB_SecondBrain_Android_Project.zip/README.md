# SB — Second Brain

Native Android project for the SB app.

Version 1 foundation:
- AI Brain home screen
- Voice button placeholder
- Proactive reminder section
- Goals/routine foundation
- Native Android UI
- Bottom navigation

## Build
Open this project in Android Studio and let Gradle sync.
Then choose:
Build → Build Bundle(s) / APK(s) → Build APK(s)

The generated debug APK is normally under:
app/build/outputs/apk/debug/app-debug.apk

Note: The AI/voice backend and exact scheduled notification engine still need their service/API configuration. This project is the native app foundation, not a falsely claimed finished APK.

package com.sb.secondbrain

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Reminder(val title: String, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SBApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SBApp() {
    var selected by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    var reminders by remember {
        mutableStateOf(
            listOf(
                Reminder("Morning routine", "7:00 AM"),
                Reminder("Exercise", "6:00 PM")
            )
        )
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("SB • Second Brain") },
                    actions = {
                        IconButton(onClick = { }) {
                            Icon(Icons.Default.Notifications, "Reminders")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = selected == 0,
                        onClick = { selected = 0 },
                        icon = { Icon(Icons.Default.Home, null) },
                        label = { Text("Brain") }
                    )
                    NavigationBarItem(
                        selected = selected == 1,
                        onClick = { selected = 1 },
                        icon = { Icon(Icons.Default.Alarm, null) },
                        label = { Text("Reminders") }
                    )
                    NavigationBarItem(
                        selected = selected == 2,
                        onClick = { selected = 2 },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("Settings") }
                    )
                }
            }
        ) { padding ->
            when (selected) {
                0 -> BrainScreen(input, { input = it })
                1 -> ReminderScreen(reminders)
                2 -> SettingsScreen()
            }
        }
    }
}

@Composable
fun BrainScreen(input: String, onInput: (String) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Good evening 👋", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Your Second Brain is ready. Tell me what you want to do next.",
            style = MaterialTheme.typography.bodyLarge
        )

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("🧠 AI Brain", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text("Goals, routine, progress and next actions will appear here.")
            }
        }

        OutlinedTextField(
            value = input,
            onValueChange = onInput,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Type something…") },
            trailingIcon = {
                IconButton(onClick = { }) {
                    Icon(Icons.Default.Mic, "Voice")
                }
            }
        )

        Button(
            onClick = { },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Send, null)
            Spacer(Modifier.width(8.dp))
            Text("Ask SB")
        }

        Card(Modifier.fillMaxWidth()) {
            Row(
                Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.AutoAwesome, null)
                Spacer(Modifier.width(12.dp))
                Text("Proactive reminder system is ready to be connected.")
            }
        }
    }
}

@Composable
fun ReminderScreen(reminders: List<Reminder>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("🔔 Proactive Reminders", style = MaterialTheme.typography.headlineSmall)
            Text("SB will remind you at the right time.")
        }
        items(reminders) { reminder ->
            Card(Modifier.fillMaxWidth()) {
                ListItem(
                    headlineContent = { Text(reminder.title) },
                    supportingContent = { Text(reminder.time) },
                    leadingContent = { Icon(Icons.Default.Alarm, null) }
                )
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Text("Voice replies, notification permission and AI connection will be configured here.")
    }
}
